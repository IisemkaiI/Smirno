@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    py -3 -m venv .venv || python -m venv .venv || goto :error
)
call ".venv\Scripts\activate.bat"
python -m pip install --quiet -r requirements.txt || goto :error
python main.py
goto :eof
:error
echo.
echo Failed. Make sure Python 3.10+ is installed and added to PATH.
pause
