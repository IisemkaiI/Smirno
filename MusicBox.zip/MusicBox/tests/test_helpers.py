import unittest

from musicbox.formatting import format_time
from musicbox.metadata import guess_title_artist


class TestHelpers(unittest.TestCase):
    def test_format_time(self):
        self.assertEqual(format_time(0), "0:00")
        self.assertEqual(format_time(65_400), "1:05")
        self.assertEqual(format_time(3_725_000), "1:02:05")
        self.assertEqual(format_time(-5), "0:00")

    def test_guess_title_artist(self):
        self.assertEqual(guess_title_artist("/m/Кино - Звезда.mp3"), ("Звезда", "Кино"))
        self.assertEqual(guess_title_artist("/m/song.mp3"), ("song", "Неизвестный исполнитель"))
        self.assertEqual(guess_title_artist("/m/a - b - c.mp3"), ("b - c", "a"))
        self.assertEqual(guess_title_artist("/m/ - x.mp3")[1], "Неизвестный исполнитель")


if __name__ == "__main__":
    unittest.main()
