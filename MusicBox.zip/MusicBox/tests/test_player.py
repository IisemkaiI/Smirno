import tempfile
import unittest
from pathlib import Path

from musicbox.models import Track
from musicbox.playback import PlaybackController
from musicbox.player_states import (
    PausedState, PlaybackStatus, PlayingState, StoppedState,
)
from tests.fakes import FakeBackend


def make_tracks(tmp, n=3):
    tracks = []
    for i in range(1, n + 1):
        p = Path(tmp) / f"t{i}.mp3"
        p.write_bytes(b"x")
        tracks.append(Track(i, f"T{i}", "A", str(p)))
    return tracks


class PlayerTestCase(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tracks = make_tracks(tmp.name)
        self.backend = FakeBackend()
        self.player = PlaybackController(self.backend)
        self.errors, self.messages, self.states, self.current = [], [], [], []
        self.player.error.connect(self.errors.append)
        self.player.message.connect(self.messages.append)
        self.player.state_changed.connect(lambda s: self.states.append(type(s)))
        self.player.track_changed.connect(self.current.append)


class TestStateTransitions(PlayerTestCase):
    def test_initial_state_and_available_actions(self):
        s = self.player.state
        self.assertIsInstance(s, StoppedState)
        self.assertEqual((s.can_play, s.can_pause, s.can_stop), (True, False, False))

    def test_play_without_track_does_nothing(self):
        self.player.play()
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertEqual(self.backend.calls, [])
        self.assertTrue(self.messages)

    def test_pause_and_stop_ignored_in_stopped_state(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.stop()
        self.backend.calls.clear()
        self.player.pause()
        self.player.stop()
        self.assertEqual(self.backend.calls, [])

    def test_full_cycle(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.assertIsInstance(self.player.state, PlayingState)
        self.assertEqual(self.backend.status, PlaybackStatus.PLAYING)
        self.player.pause()
        self.assertIsInstance(self.player.state, PausedState)
        self.assertEqual(self.backend.status, PlaybackStatus.PAUSED)
        self.player.play()                       # возобновление с паузы
        self.assertIsInstance(self.player.state, PlayingState)
        self.player.stop()
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertEqual(self.backend.status, PlaybackStatus.STOPPED)

    def test_available_actions_follow_state(self):
        self.player.play_track(self.tracks[0], self.tracks)
        s = self.player.state
        self.assertEqual((s.can_play, s.can_pause, s.can_stop, s.can_seek), (False, True, True, True))
        self.player.pause()
        s = self.player.state
        self.assertEqual((s.can_play, s.can_pause, s.can_stop, s.can_seek), (True, False, True, True))

    def test_play_while_playing_does_not_restart(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.calls.clear()
        self.player.play()
        self.assertEqual(self.backend.calls, [])

    def test_toggle(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.toggle()
        self.assertIsInstance(self.player.state, PausedState)
        self.player.toggle()
        self.assertIsInstance(self.player.state, PlayingState)

    def test_resume_after_stop_keeps_track(self):
        """Баг №3: после Stop воспроизведение возобновляется, трек не теряется."""
        self.player.play_track(self.tracks[1], self.tracks)
        self.player.stop()
        self.assertEqual(self.player.current_track, self.tracks[1])
        self.player.play()
        self.assertIsInstance(self.player.state, PlayingState)
        self.assertEqual(self.backend.source, self.tracks[1].path)

    def test_source_loaded_only_when_track_changes(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.stop()
        self.player.play()
        self.assertEqual(self.backend.names().count("load"), 1)

    def test_state_changed_events_only_on_real_transitions(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.play()
        self.player.pause()
        self.player.pause()
        self.assertEqual(self.states, [PlayingState, PausedState])

    def test_seek_only_when_state_allows(self):
        self.player.seek(1000)
        self.assertNotIn("seek", self.backend.names())
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.seek(1500)
        self.assertEqual(self.backend.position, 1500)

    def test_volume_is_clamped(self):
        self.player.set_volume(150)
        self.assertEqual(self.backend.volume, 100)
        self.player.set_volume(-5)
        self.assertEqual(self.backend.volume, 0)


class TestBackendSync(PlayerTestCase):
    def test_external_pause_is_adopted(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.external_state(PlaybackStatus.PAUSED)
        self.assertIsInstance(self.player.state, PausedState)

    def test_external_stop_is_adopted(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.external_state(PlaybackStatus.STOPPED)
        self.assertIsInstance(self.player.state, StoppedState)

    def test_matching_backend_event_is_noop(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.external_state(PlaybackStatus.PLAYING)
        self.assertEqual(self.states, [PlayingState])

    def test_end_of_track_autoplays_next(self):
        """Баги №1 и №6: автопереход и обновление состояния по окончании трека."""
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.finish_track()
        self.assertEqual(self.player.current_track, self.tracks[1])
        self.assertIsInstance(self.player.state, PlayingState)
        self.assertEqual(self.backend.source, self.tracks[1].path)
        self.assertEqual(self.current, [self.tracks[0], self.tracks[1]])

    def test_end_of_last_track_stops_and_notifies(self):
        self.player.play_track(self.tracks[2], self.tracks)
        self.backend.finish_track()
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertEqual(self.player.current_track, self.tracks[2])   # можно сыграть снова
        self.assertIn("Очередь завершена.", self.messages)
        self.player.play()
        self.assertIsInstance(self.player.state, PlayingState)

    def test_single_track_ends_in_stopped(self):
        self.player.play_track(self.tracks[0], [self.tracks[0]])
        self.backend.finish_track()
        self.assertIsInstance(self.player.state, StoppedState)

    def test_end_event_ignored_when_not_playing(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.stop()
        self.backend.ended.emit()
        self.assertEqual(self.player.current_track, self.tracks[0])
        self.assertIsInstance(self.player.state, StoppedState)

    def test_backend_error_stops_and_reports(self):
        """Баг №2: ошибки плеера превращаются в Stopped + сообщение."""
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.fail("bad codec")
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertEqual(self.errors, ["bad codec"])
        self.assertEqual(self.player.current_track, self.tracks[0])

    def test_retry_after_error_reloads_source(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.backend.fail()
        self.player.play()
        self.assertEqual(self.backend.names().count("load"), 2)
        self.assertIsInstance(self.player.state, PlayingState)

    def test_missing_file_is_reported_not_played(self):
        Path(self.tracks[0].path).unlink()
        self.player.play_track(self.tracks[0], self.tracks)
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertIn("Файл не найден", self.errors[0])
        self.assertNotIn("play", self.backend.names())

    def test_position_and_duration_forwarded(self):
        pos, dur = [], []
        self.player.position_changed.connect(pos.append)
        self.player.duration_changed.connect(dur.append)
        self.backend.position_changed.emit(500)
        self.backend.duration_changed.emit(90000)
        self.assertEqual((pos, dur), ([500], [90000]))


class TestQueue(PlayerTestCase):
    def test_next_previous_wrap_around(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.previous()
        self.assertEqual(self.player.current_track, self.tracks[2])
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[0])
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[1])

    def test_next_from_stopped_starts_playing(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.stop()
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[1])
        self.assertIsInstance(self.player.state, PlayingState)

    def test_next_from_paused_replaces_track(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.pause()
        self.player.next()
        self.assertIsInstance(self.player.state, PlayingState)
        self.assertEqual(self.backend.source, self.tracks[1].path)

    def test_queue_is_independent_of_search_filter(self):
        """Баг №4: очередь — полный источник, а не отфильтрованный список окна.
        Окно передаёт в очередь весь источник; фильтр поиска её не меняет."""
        full_queue = self.tracks
        self.player.play_track(self.tracks[0], full_queue)
        # пользователь вводит поиск — в окне остаётся 1 трек, очередь прежняя
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[1])

    def test_next_with_empty_queue(self):
        self.player.next()
        self.assertTrue(self.messages)
        self.assertIsInstance(self.player.state, StoppedState)

    def test_set_queue_keeps_current_playing(self):
        self.player.play_track(self.tracks[1], self.tracks)
        self.player.set_queue([self.tracks[2], self.tracks[1]])
        self.assertIsInstance(self.player.state, PlayingState)
        self.player.next()                      # индекс пересчитан: после T2 идёт T3-wrap -> T3
        self.assertEqual(self.player.current_track, self.tracks[2])

    def test_current_track_not_in_new_queue(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.set_queue([self.tracks[1], self.tracks[2]])
        self.assertIsInstance(self.player.state, PlayingState)
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[1])
        self.player.set_queue([self.tracks[1], self.tracks[2]])
        self.backend.finish_track()
        self.assertEqual(self.player.current_track, self.tracks[2])

    def test_end_of_orphan_track_stops(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.set_queue([self.tracks[1]])
        self.backend.finish_track()
        self.assertIsInstance(self.player.state, StoppedState)

    def test_removing_playing_track_stops_playback(self):
        """Баг №5: удаление играющего трека останавливает плеер и сбрасывает трек."""
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.remove_track(self.tracks[0].id)
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertIsNone(self.player.current_track)
        self.assertEqual(self.current[-1], None)
        self.assertNotIn(self.tracks[0], self.player.queue)
        self.assertEqual(self.backend.status, PlaybackStatus.STOPPED)
        self.assertIsNone(self.backend.source)

    def test_removing_other_track_keeps_playing(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.remove_track(self.tracks[1].id)
        self.assertIsInstance(self.player.state, PlayingState)
        self.player.next()
        self.assertEqual(self.player.current_track, self.tracks[2])

    def test_removing_paused_track(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.pause()
        self.player.remove_track(self.tracks[0].id)
        self.assertIsInstance(self.player.state, StoppedState)

    def test_shutdown_stops(self):
        self.player.play_track(self.tracks[0], self.tracks)
        self.player.shutdown()
        self.assertEqual(self.backend.status, PlaybackStatus.STOPPED)


if __name__ == "__main__":
    unittest.main()
