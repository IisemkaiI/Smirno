"""Заглушка медиа-бэкенда, повторяющая поведение QMediaPlayer, нужное логике плеера."""
from musicbox.events import Event
from musicbox.player_states import PlaybackStatus


class FakeBackend:
    def __init__(self):
        self.state_changed = Event()
        self.ended = Event()
        self.error = Event()
        self.position_changed = Event()
        self.duration_changed = Event()
        self.source = None
        self.status = PlaybackStatus.STOPPED
        self.volume = None
        self.position = 0
        self.calls = []

    # команды (как в QMediaPlayer, состояние меняется сразу)
    def load(self, path):
        self.calls.append(("load", path))
        self.source = path

    def clear_source(self):
        self.calls.append(("clear",))
        self.source = None

    def play(self):
        self.calls.append(("play",))
        self.status = PlaybackStatus.PLAYING

    def pause(self):
        self.calls.append(("pause",))
        self.status = PlaybackStatus.PAUSED

    def stop(self):
        self.calls.append(("stop",))
        self.status = PlaybackStatus.STOPPED

    def set_position(self, ms):
        self.position = ms
        self.calls.append(("seek", ms))

    def set_volume(self, percent):
        self.volume = percent

    # события «снаружи»
    def finish_track(self):
        self.status = PlaybackStatus.STOPPED
        self.ended.emit()
        self.state_changed.emit(self.status)

    def external_state(self, status):
        self.status = status
        self.state_changed.emit(status)

    def fail(self, message="decode error"):
        self.status = PlaybackStatus.STOPPED
        self.error.emit(message)
        self.state_changed.emit(self.status)

    def names(self):
        return [c[0] for c in self.calls]
