import sqlite3
import tempfile
import unittest
from pathlib import Path

from musicbox.commands import (
    AddTrack, AddTrackToPlaylist, CommandHandler, CreatePlaylist, DeletePlaylist,
    RemoveTrack, RemoveTrackFromPlaylist, RenamePlaylist,
)
from musicbox.database import Database
from musicbox.errors import (
    DuplicatePlaylistError, DuplicateTrackError, InvalidPlaylistNameError,
    InvalidTrackError, PlaylistNotFoundError, TrackNotFoundError,
)
from musicbox.queries import GetPlaylists, GetPlaylistTracks, GetTracks, QueryHandler


class CqrsTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db_path = Path(self.tmp.name) / "test.db"
        self.db = Database(self.db_path)
        self.addCleanup(self.db.close)
        self.cmd = CommandHandler(self.db)
        self.qry = QueryHandler(self.db)

    def make_file(self, name):
        p = Path(self.tmp.name) / name
        p.write_bytes(b"x")
        return str(p)

    def add(self, name, **kw):
        return self.cmd.execute(AddTrack(self.make_file(name), **kw))


class TestTrackCommands(CqrsTestCase):
    def test_add_and_list(self):
        self.add("Queen - Bohemian.mp3")
        tracks = self.qry.ask(GetTracks())
        self.assertEqual([(t.title, t.artist) for t in tracks], [("Bohemian", "Queen")])

    def test_unknown_artist_and_explicit_metadata(self):
        self.add("song.mp3")
        self.add("x.mp3", title="Моя песня", artist="Я")
        by_title = {t.title: t.artist for t in self.qry.ask(GetTracks())}
        self.assertEqual(by_title["song"], "Неизвестный исполнитель")
        self.assertEqual(by_title["Моя песня"], "Я")

    def test_duplicate_path_is_reported(self):
        path = self.make_file("a.mp3")
        self.cmd.execute(AddTrack(path))
        with self.assertRaises(DuplicateTrackError):
            self.cmd.execute(AddTrack(path))
        self.assertEqual(len(self.qry.ask(GetTracks())), 1)

    def test_missing_file_and_bad_extension(self):
        with self.assertRaises(InvalidTrackError):
            self.cmd.execute(AddTrack(str(Path(self.tmp.name) / "nope.mp3")))
        with self.assertRaises(InvalidTrackError):
            self.cmd.execute(AddTrack(self.make_file("notes.txt")))

    def test_remove_track_cascades_to_playlists(self):
        t = self.add("a.mp3")
        p = self.cmd.execute(CreatePlaylist("Mix"))
        self.cmd.execute(AddTrackToPlaylist(p, t))
        self.cmd.execute(RemoveTrack(t))
        self.assertEqual(self.qry.ask(GetTracks()), [])
        self.assertEqual(self.qry.ask(GetPlaylistTracks(p)), [])
        # проверяем именно каскад, а не ручную очистку: строк-сирот в связи нет
        orphans = self.db.write.execute("SELECT COUNT(*) FROM playlist_tracks").fetchone()[0]
        self.assertEqual(orphans, 0)

    def test_remove_missing_track(self):
        with self.assertRaises(TrackNotFoundError):
            self.cmd.execute(RemoveTrack(999))

    def test_foreign_keys_enforced(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.write.execute("INSERT INTO playlist_tracks VALUES (1, 1)")


class TestPlaylistCommands(CqrsTestCase):
    def test_create_rename_delete(self):
        p = self.cmd.execute(CreatePlaylist("  Rock  "))
        self.assertEqual([x.name for x in self.qry.ask(GetPlaylists())], ["Rock"])
        self.cmd.execute(RenamePlaylist(p, "Metal"))
        self.assertEqual([x.name for x in self.qry.ask(GetPlaylists())], ["Metal"])
        self.cmd.execute(DeletePlaylist(p))
        self.assertEqual(self.qry.ask(GetPlaylists()), [])

    def test_duplicate_and_empty_names_are_errors(self):
        self.cmd.execute(CreatePlaylist("Рок"))
        with self.assertRaises(DuplicatePlaylistError):
            self.cmd.execute(CreatePlaylist("рок"))     # регистр не важен, и для кириллицы
        with self.assertRaises(InvalidPlaylistNameError):
            self.cmd.execute(CreatePlaylist("   "))

    def test_rename_to_same_name_with_other_case_is_allowed(self):
        p = self.cmd.execute(CreatePlaylist("rock"))
        self.cmd.execute(RenamePlaylist(p, "Rock"))
        self.assertEqual(self.qry.ask(GetPlaylists())[0].name, "Rock")

    def test_rename_to_existing_name_fails(self):
        self.cmd.execute(CreatePlaylist("A"))
        b = self.cmd.execute(CreatePlaylist("B"))
        with self.assertRaises(DuplicatePlaylistError):
            self.cmd.execute(RenamePlaylist(b, "a"))

    def test_unknown_playlist(self):
        for command in (RenamePlaylist(5, "x"), DeletePlaylist(5)):
            with self.assertRaises(PlaylistNotFoundError):
                self.cmd.execute(command)
        t = self.add("a.mp3")
        with self.assertRaises(PlaylistNotFoundError):
            self.cmd.execute(AddTrackToPlaylist(5, t))

    def test_add_unknown_track_to_playlist(self):
        p = self.cmd.execute(CreatePlaylist("P"))
        with self.assertRaises(TrackNotFoundError):
            self.cmd.execute(AddTrackToPlaylist(p, 12345))

    def test_playlist_keeps_insertion_order_and_dedups(self):
        p = self.cmd.execute(CreatePlaylist("P"))
        b, a = self.add("b.mp3"), self.add("a.mp3")
        self.cmd.execute(AddTrackToPlaylist(p, b))
        self.cmd.execute(AddTrackToPlaylist(p, a))
        self.cmd.execute(AddTrackToPlaylist(p, b))      # повтор — без эффекта
        self.assertEqual([t.title for t in self.qry.ask(GetPlaylistTracks(p))], ["b", "a"])
        self.assertEqual(self.qry.ask(GetPlaylists())[0].track_count, 2)

    def test_remove_track_from_playlist_keeps_library_track(self):
        p = self.cmd.execute(CreatePlaylist("P"))
        t = self.add("a.mp3")
        self.cmd.execute(AddTrackToPlaylist(p, t))
        self.cmd.execute(RemoveTrackFromPlaylist(p, t))
        self.assertEqual(self.qry.ask(GetPlaylistTracks(p)), [])
        self.assertEqual(len(self.qry.ask(GetTracks())), 1)

    def test_delete_playlist_keeps_tracks(self):
        p = self.cmd.execute(CreatePlaylist("P"))
        t = self.add("a.mp3")
        self.cmd.execute(AddTrackToPlaylist(p, t))
        self.cmd.execute(DeletePlaylist(p))
        self.assertEqual(len(self.qry.ask(GetTracks())), 1)


class TestQueries(CqrsTestCase):
    def test_search_is_case_insensitive_for_cyrillic(self):
        self.add("Кино - Группа крови.mp3")
        self.add("Queen - Bohemian.mp3")
        self.assertEqual([t.artist for t in self.qry.ask(GetTracks("ГРУППА"))], ["Кино"])
        self.assertEqual([t.artist for t in self.qry.ask(GetTracks("кино"))], ["Кино"])
        self.assertEqual([t.artist for t in self.qry.ask(GetTracks("QUEEN"))], ["Queen"])
        self.assertEqual(self.qry.ask(GetTracks("нет такого")), [])

    def test_search_treats_wildcards_literally(self):
        self.add("100%.mp3")
        self.add("other.mp3")
        self.assertEqual([t.title for t in self.qry.ask(GetTracks("%"))], ["100%"])
        self.assertEqual(self.qry.ask(GetTracks("_")), [])

    def test_sorting_ignores_case_for_cyrillic(self):
        for n in ("б.mp3", "А.mp3", "в.mp3"):
            self.add(n)
        self.assertEqual([t.title for t in self.qry.ask(GetTracks())], ["А", "б", "в"])

    def test_search_within_playlist(self):
        p = self.cmd.execute(CreatePlaylist("P"))
        for n in ("Alpha.mp3", "Beta.mp3"):
            self.cmd.execute(AddTrackToPlaylist(p, self.add(n)))
        self.add("Alphabet.mp3")  # в библиотеке, но не в плейлисте
        self.assertEqual([t.title for t in self.qry.ask(GetPlaylistTracks(p, "alp"))], ["Alpha"])

    def test_queries_cannot_modify_data(self):
        """Read-соединение защищено на уровне SQLite — это и есть разделение CQRS."""
        with self.assertRaises(sqlite3.OperationalError):
            self.db.read.execute("INSERT INTO playlists(name) VALUES ('hack')")

    def test_unknown_message_types_rejected(self):
        with self.assertRaises(TypeError):
            self.cmd.execute(GetTracks())      # запрос нельзя выполнить как команду
        with self.assertRaises(TypeError):
            self.qry.ask(AddTrack("x"))        # команду нельзя выполнить как запрос


class TestPersistence(CqrsTestCase):
    def test_data_survives_restart(self):
        t = self.add("Artist - Song.mp3")
        p = self.cmd.execute(CreatePlaylist("Любимое"))
        self.cmd.execute(AddTrackToPlaylist(p, t))
        self.db.close()

        db2 = Database(self.db_path)
        self.addCleanup(db2.close)
        qry = QueryHandler(db2)
        self.assertEqual([x.title for x in qry.ask(GetTracks())], ["Song"])
        self.assertEqual([(x.name, x.track_count) for x in qry.ask(GetPlaylists())], [("Любимое", 1)])

    def test_memory_database(self):
        db = Database(":memory:")
        CommandHandler(db).execute(CreatePlaylist("x"))
        self.assertEqual(len(QueryHandler(db).ask(GetPlaylists())), 1)
        db.close()


if __name__ == "__main__":
    unittest.main()
