"""Мини-имитация PySide6 для проверки ЛОГИКИ окна без графической среды.

Это не эмулятор Qt: отрисовка, стили и реальные сигналы не проверяются.
Заглушка хранит состояние виджетов (текст, значения, элементы списков), чтобы
тест мог прогнать сценарии MainWindow: добавление файлов, воспроизведение,
удаление играющего трека и т.д.
"""
import inspect
import sys
import types


class Signal:
    def __init__(self):
        self.handlers = []

    def connect(self, handler):
        self.handlers.append(handler)

    def emit(self, *args):
        # PySide6 передаёт слоту только те аргументы, которые он принимает.
        for h in list(self.handlers):
            try:
                params = inspect.signature(h).parameters.values()
            except (TypeError, ValueError):
                h(*args)
                continue
            if any(p.kind is p.VAR_POSITIONAL for p in params):
                h(*args)
            else:
                h(*args[:len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)])])


SIGNALS = {
    "clicked", "textChanged", "valueChanged", "sliderMoved", "sliderReleased",
    "currentRowChanged", "itemDoubleClicked", "customContextMenuRequested",
    "activated", "triggered",
}


class Dyn:
    """Принимает любые вызовы и обращения к атрибутам."""

    def __init__(self, *args, **kwargs):
        self.__dict__["_signals"] = {}

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        if name in SIGNALS:
            return self._signals.setdefault(name, Signal())
        return Dyn()

    def __call__(self, *args, **kwargs):
        return Dyn()

    def __iter__(self):
        return iter(())


class Widget(Dyn):
    def __init__(self, text="", *a, **k):
        super().__init__()
        self._text = text if isinstance(text, str) else ""
        self._enabled = True
        self._tooltip = ""

    def setText(self, t): self._text = t
    def text(self): return self._text
    def setEnabled(self, v): self._enabled = bool(v)
    def isEnabled(self): return self._enabled
    def setToolTip(self, t): self._tooltip = t
    def blockSignals(self, b): return False
    def setObjectName(self, n): self.name = n
    def clear(self): self._text = ""


class Slider(Widget):
    def __init__(self, *a):
        super().__init__()
        self.lo, self.hi, self.val = 0, 0, 0

    def setRange(self, lo, hi): self.lo, self.hi = lo, hi
    def setValue(self, v): self.val = v
    def value(self): return self.val
    def isSliderDown(self): return False


class Item(Dyn):
    def __init__(self, texts=""):
        super().__init__()
        self.texts = list(texts) if isinstance(texts, (list, tuple)) else [texts]
        self.store = {}
        self.selected = False
        self._font = Font()

    def setText(self, col, t=None):
        if t is None:
            col, t = 0, col
        while len(self.texts) <= col:
            self.texts.append("")
        self.texts[col] = t

    def text(self, col=0): return self.texts[col]
    def setData(self, col, role, value=None):
        if value is None and not isinstance(col, int):
            col, role, value = 0, col, role
        self.store[col] = value
    def data(self, col, role=None):
        if role is None:
            col = 0
        return self.store.get(col)
    def setSelected(self, v): self.selected = v
    def isSelected(self): return self.selected
    def font(self, col=0): return self._font
    def setFont(self, col, f): self._font = f


class Font(Dyn):
    def __init__(self, *a):
        super().__init__()
        self.bold = False

    def setBold(self, v): self.bold = v


class ListWidget(Widget):
    def __init__(self, *a):
        super().__init__()
        self.items, self.row = [], -1

    def clear(self): self.items, self.row = [], -1
    def addItem(self, item): self.items.append(item)
    def item(self, i): return self.items[i] if 0 <= i < len(self.items) else None
    def setCurrentRow(self, r): self.row = r
    def currentRow(self): return self.row


class TreeWidget(Widget):
    def __init__(self, *a):
        super().__init__()
        self.items = []

    def clear(self): self.items = []
    def addTopLevelItem(self, i): self.items.append(i)
    def topLevelItemCount(self): return len(self.items)
    def topLevelItem(self, i): return self.items[i]
    def selectedItems(self): return [i for i in self.items if i.selected]
    def clearSelection(self):
        for i in self.items: i.selected = False
    def setCurrentItem(self, item):
        self.clearSelection(); item.selected = True


class StatusBar(Dyn):
    def __init__(self):
        super().__init__()
        self.messages = []

    def showMessage(self, text, timeout=0): self.messages.append(text)


class MainWindow(Widget):
    def __init__(self, *a):
        super().__init__()
        self._status = StatusBar()
        self.title = ""

    def statusBar(self): return self._status
    def setWindowTitle(self, t): self.title = t
    def closeEvent(self, e): pass


class Stack(Widget):
    def __init__(self, *a):
        super().__init__()
        self.index = 0

    def setCurrentIndex(self, i): self.index = i


class Dialogs:
    """Ответы диалогов задаёт тест через атрибуты класса."""
    warnings = []
    answer_yes = True
    file_paths = []
    input_text = ("", True)


class MessageBox(Dyn):
    class StandardButton:
        Yes, No = "Yes", "No"

    @staticmethod
    def question(*a): return "Yes" if Dialogs.answer_yes else "No"

    @staticmethod
    def warning(parent, title, text): Dialogs.warnings.append(text)


class FileDialog(Dyn):
    @staticmethod
    def getOpenFileNames(*a): return (list(Dialogs.file_paths), "")


class InputDialog(Dyn):
    @staticmethod
    def getText(*a): return Dialogs.input_text


def _module(name, **attrs):
    mod = types.ModuleType(name)
    mod.__dict__.update(attrs)
    mod.__getattr__ = lambda n: Dyn()
    return mod


def install():
    """Подставить модули-заглушки. Возвращает функцию, откатывающую подмену."""
    names = ["PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets", "PySide6.QtMultimedia"]
    saved = {n: sys.modules.get(n) for n in names + ["musicbox.main_window"]}
    widgets = _module(
        "PySide6.QtWidgets",
        QMainWindow=MainWindow, QSlider=Slider, QListWidget=ListWidget,
        QListWidgetItem=Item, QTreeWidget=TreeWidget, QTreeWidgetItem=Item,
        QStackedWidget=Stack, QMessageBox=MessageBox, QFileDialog=FileDialog,
        QInputDialog=InputDialog, QLabel=Widget, QPushButton=Widget, QLineEdit=Widget,
        QWidget=Widget, QFrame=Widget, QMenu=Dyn(),
        QVBoxLayout=Dyn(), QHBoxLayout=Dyn(), QHeaderView=Dyn(), QAbstractItemView=Dyn(),
        QSizePolicy=Dyn(),
    )
    sys.modules.update({
        "PySide6": _module("PySide6"),
        "PySide6.QtCore": _module("PySide6.QtCore", Qt=Dyn()),
        "PySide6.QtGui": _module("PySide6.QtGui", QFont=Font, QKeySequence=Dyn(), QShortcut=Dyn()),
        "PySide6.QtWidgets": widgets,
    })
    sys.modules.pop("musicbox.main_window", None)

    def restore():
        for n, mod in saved.items():
            if mod is None:
                sys.modules.pop(n, None)
            else:
                sys.modules[n] = mod
    return restore
