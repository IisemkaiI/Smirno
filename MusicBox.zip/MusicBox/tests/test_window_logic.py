"""Сценарии MainWindow на заглушке Qt (см. qt_stub.py): проверяется логика связки
окно ↔ команды/запросы ↔ плеер, но не отрисовка."""
import tempfile
import unittest
from pathlib import Path

from tests import qt_stub
from tests.fakes import FakeBackend

from musicbox.commands import CommandHandler
from musicbox.database import Database
from musicbox.playback import PlaybackController
from musicbox.player_states import PausedState, PlayingState, StoppedState
from musicbox.queries import QueryHandler


class WindowLogicTest(unittest.TestCase):
    def setUp(self):
        self.restore = qt_stub.install()
        self.addCleanup(self.restore)
        from musicbox.main_window import ROLE_ID, MainWindow
        self.ROLE_ID = ROLE_ID
        qt_stub.Dialogs.warnings = []
        qt_stub.Dialogs.answer_yes = True

        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Database(Path(self.tmp.name) / "db.sqlite")
        self.addCleanup(self.db.close)
        self.backend = FakeBackend()
        self.player = PlaybackController(self.backend)
        self.win = MainWindow(CommandHandler(self.db), QueryHandler(self.db), self.player)

    def files(self, *names):
        out = []
        for n in names:
            p = Path(self.tmp.name) / n
            p.write_bytes(b"x")
            out.append(str(p))
        return out

    def titles(self):
        t = self.win.track_tree
        return [t.topLevelItem(i).text(1) for i in range(t.topLevelItemCount())]

    def double_click(self, row):
        item = self.win.track_tree.topLevelItem(row)
        self.win.track_tree.itemDoubleClicked.emit(item, 0)

    def test_empty_library_shows_hint_and_play_does_nothing(self):
        self.assertEqual(self.win.stack.index, 1)
        self.win.play_button.clicked.emit(False)
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertTrue(self.win.statusBar().messages)

    def test_add_files_reports_duplicates_and_bad_files(self):
        paths = self.files("B.mp3", "A.mp3", "doc.txt")
        self.win._import_paths(paths)
        self.assertEqual(self.titles(), ["A", "B"])
        self.assertEqual(self.win.stack.index, 0)
        self.assertEqual(len(qt_stub.Dialogs.warnings), 1)       # doc.txt
        self.win._import_paths(paths[:2])
        self.assertIn("уже были", self.win.statusBar().messages[-1])

    def test_play_pause_stop_buttons_follow_state(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3"))
        self.double_click(0)
        self.assertIsInstance(self.player.state, PlayingState)
        self.assertEqual(self.win.play_button.text(), "❚❚")
        self.assertTrue(self.win.stop_button.isEnabled())
        self.assertEqual(self.win.track_tree.topLevelItem(0).text(0), "▶")
        self.win.play_button.clicked.emit(False)
        self.assertIsInstance(self.player.state, PausedState)
        self.assertEqual(self.win.play_button.text(), "▶")
        self.assertEqual(self.win.track_tree.topLevelItem(0).text(0), "❚❚")
        self.win.stop_button.clicked.emit(False)
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertFalse(self.win.stop_button.isEnabled())
        self.assertFalse(self.win.seek_slider.isEnabled())

    def test_stop_then_play_resumes_same_track_when_selection_follows(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3", "C.mp3"))
        self.double_click(0)
        self.backend.finish_track()                  # автопереход на B, выделение следует
        self.assertEqual(self.player.current_track.title, "B")
        self.win.stop_button.clicked.emit(False)
        self.win.play_button.clicked.emit(False)
        self.assertEqual(self.player.current_track.title, "B")
        self.assertIsInstance(self.player.state, PlayingState)

    def test_autoplay_updates_ui(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3"))
        self.double_click(0)
        self.backend.finish_track()
        self.assertEqual(self.win.np_title.text(), "B")
        self.assertEqual(self.win.track_tree.topLevelItem(1).text(0), "▶")
        self.backend.finish_track()                  # конец очереди
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertEqual(self.win.play_button.text(), "▶")
        self.assertIn("Очередь завершена.", self.win.statusBar().messages)

    def test_next_uses_full_library_not_search_results(self):
        self.win._import_paths(self.files("Alpha.mp3", "Beta.mp3", "Gamma.mp3"))
        self.double_click(0)                          # играет Alpha
        self.win.search.setText("gam")
        self.win.search.textChanged.emit("gam")      # в таблице остался один трек
        self.assertEqual(self.titles(), ["Gamma"])
        self.win.next_button.clicked.emit(False)
        self.assertEqual(self.player.current_track.title, "Beta")

    def test_removing_playing_track_stops_and_clears_status(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3"))
        self.double_click(0)
        self.win.track_tree.setCurrentItem(self.win.track_tree.topLevelItem(0))
        self.win._remove_from_library(self.win._selected_tracks())
        self.assertIsInstance(self.player.state, StoppedState)
        self.assertIsNone(self.player.current_track)
        self.assertEqual(self.win.np_title.text(), "Ничего не выбрано")
        self.assertEqual(self.titles(), ["B"])

    def test_playback_error_shown_in_status_bar(self):
        self.win._import_paths(self.files("A.mp3"))
        self.double_click(0)
        self.backend.fail("codec missing")
        self.assertIn("⚠  codec missing", self.win.statusBar().messages)
        self.assertIsInstance(self.player.state, StoppedState)

    def test_playlist_flow(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3"))
        qt_stub.Dialogs.input_text = ("Мой плейлист", True)
        pid = self.win._create_playlist()
        self.assertIsNotNone(pid)
        self.win._add_to_playlist(pid, [self.win._view_tracks[1]])
        # открыть плейлист в боковой панели
        row = next(i for i, it in enumerate(self.win.source_list.items) if it.data(0, self.ROLE_ID) == pid)
        self.win.source_list.currentRowChanged.emit(row)
        self.assertEqual(self.titles(), ["B"])
        self.assertIn("1", self.win.source_list.items[row].text())
        # убрать из плейлиста
        self.win._remove_from_playlist(self.win._view_tracks)
        self.assertEqual(self.titles(), [])
        self.assertEqual(self.win.stack.index, 1)

    def test_duplicate_playlist_name_shows_warning(self):
        qt_stub.Dialogs.input_text = ("Рок", True)
        self.win._create_playlist()
        self.assertIsNone(self.win._create_playlist())
        self.assertIn("уже существует", qt_stub.Dialogs.warnings[-1])

    def test_deleting_playlist_returns_to_library(self):
        qt_stub.Dialogs.input_text = ("P", True)
        pid = self.win._create_playlist()
        self.win._view_source = pid
        self.win._delete_playlist(pid, "P")
        self.assertEqual(self.win._view_source, 0)

    def test_next_without_history_starts_from_view(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3"))
        self.win.next_button.clicked.emit(False)
        self.assertEqual(self.player.current_track.title, "A")

    def test_playing_from_playlist_queue_stays_inside_playlist(self):
        self.win._import_paths(self.files("A.mp3", "B.mp3", "C.mp3"))
        qt_stub.Dialogs.input_text = ("P", True)
        pid = self.win._create_playlist()
        self.win._add_to_playlist(pid, [self.win._view_tracks[0], self.win._view_tracks[2]])
        row = next(i for i, it in enumerate(self.win.source_list.items) if it.data(0, self.ROLE_ID) == pid)
        self.win.source_list.currentRowChanged.emit(row)
        self.double_click(0)                          # A
        self.win.next_button.clicked.emit(False)
        self.assertEqual(self.player.current_track.title, "C")   # B пропущен


if __name__ == "__main__":
    unittest.main()
