"""CQRS — сторона ЧТЕНИЯ.

Запрос — неизменяемый объект с условиями выборки. QueryHandler возвращает
модели и использует только read-соединение (PRAGMA query_only), поэтому
изменить данные из запроса невозможно.
"""
from __future__ import annotations

from dataclasses import dataclass

from .database import Database
from .models import Playlist, Track


# ---------------------------------------------------------------- запросы ---
@dataclass(frozen=True)
class GetTracks:
    """Список треков библиотеки; непустой text — поиск по названию и исполнителю."""
    text: str = ""


@dataclass(frozen=True)
class GetPlaylists:
    pass


@dataclass(frozen=True)
class GetPlaylistTracks:
    """Содержимое плейлиста в порядке добавления; text — необязательный фильтр."""
    playlist_id: int
    text: str = ""


# ------------------------------------------------------------ обработчик ---
def _like_pattern(text: str) -> str:
    escaped = text.strip().casefold().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


_TRACK_COLUMNS = "t.id, t.title, t.artist, t.path"
_MATCH = "(casefold(t.title) LIKE :p ESCAPE '\\' OR casefold(t.artist) LIKE :p ESCAPE '\\')"


class QueryHandler:
    def __init__(self, database: Database) -> None:
        self._conn = database.read
        self._routes = {
            GetTracks: self._get_tracks,
            GetPlaylists: self._get_playlists,
            GetPlaylistTracks: self._get_playlist_tracks,
        }

    def ask(self, query):
        try:
            route = self._routes[type(query)]
        except KeyError:
            raise TypeError(f"Неизвестный запрос: {type(query).__name__}") from None
        return route(query)

    @staticmethod
    def _tracks(rows) -> list[Track]:
        return [Track(r["id"], r["title"], r["artist"], r["path"]) for r in rows]

    def _get_tracks(self, q: GetTracks) -> list[Track]:
        where, params = ("", {})
        if q.text.strip():
            where, params = f"WHERE {_MATCH}", {"p": _like_pattern(q.text)}
        rows = self._conn.execute(
            f"SELECT {_TRACK_COLUMNS} FROM tracks t {where} "
            "ORDER BY t.title COLLATE CASEFOLD, t.id", params
        ).fetchall()
        return self._tracks(rows)

    def _get_playlists(self, _q: GetPlaylists) -> list[Playlist]:
        rows = self._conn.execute(
            "SELECT p.id, p.name, COUNT(pt.track_id) AS n FROM playlists p "
            "LEFT JOIN playlist_tracks pt ON pt.playlist_id = p.id "
            "GROUP BY p.id ORDER BY p.name COLLATE CASEFOLD"
        ).fetchall()
        return [Playlist(r["id"], r["name"], r["n"]) for r in rows]

    def _get_playlist_tracks(self, q: GetPlaylistTracks) -> list[Track]:
        extra, params = "", {"pid": q.playlist_id}
        if q.text.strip():
            extra, params["p"] = f"AND {_MATCH}", _like_pattern(q.text)
        rows = self._conn.execute(
            f"SELECT {_TRACK_COLUMNS} FROM tracks t "
            "JOIN playlist_tracks pt ON pt.track_id = t.id "
            f"WHERE pt.playlist_id = :pid {extra} ORDER BY pt.rowid", params
        ).fetchall()
        return self._tracks(rows)
