"""Контекст паттерна State: контроллер воспроизведения.

Не зависит от Qt. Работает с «бэкендом» — любым объектом с интерфейсом
AudioBackend (в приложении это QtAudioBackend из player.py, в тестах — заглушка).

Контроллер хранит текущий трек и очередь, делегирует действия объекту
состояния и публикует события для интерфейса (Event.connect).
"""
from __future__ import annotations

import os
from typing import Callable, Protocol

from .events import Event
from .models import Track
from .player_states import PlaybackStatus, PlayerState, StoppedState, state_for


class AudioBackend(Protocol):
    state_changed: Event      # emit(PlaybackStatus) — реальное состояние плеера
    ended: Event              # emit() — трек доигран до конца
    error: Event              # emit(str)
    position_changed: Event   # emit(ms)
    duration_changed: Event   # emit(ms)

    def load(self, path: str) -> None: ...
    def clear_source(self) -> None: ...
    def play(self) -> None: ...
    def pause(self) -> None: ...
    def stop(self) -> None: ...
    def set_position(self, ms: int) -> None: ...
    def set_volume(self, percent: int) -> None: ...


class PlaybackController:
    def __init__(self, backend: AudioBackend, file_exists: Callable[[str], bool] = os.path.isfile):
        self.backend = backend
        self._file_exists = file_exists
        self._state: PlayerState = StoppedState()
        self._track: Track | None = None
        self._queue: list[Track] = []
        self._index = -1            # позиция текущего трека в очереди, -1 — его в очереди нет
        self._loaded_path: str | None = None

        self.state_changed = Event()     # emit(PlayerState)
        self.track_changed = Event()     # emit(Track | None)
        self.queue_changed = Event()     # emit()
        self.error = Event()             # emit(str)
        self.message = Event()           # emit(str) — информационные сообщения
        self.position_changed = Event()  # emit(ms)
        self.duration_changed = Event()  # emit(ms)

        backend.state_changed.connect(lambda status: self._state.on_backend_state(self, status))
        backend.ended.connect(lambda: self._state.on_end_of_media(self))
        backend.error.connect(lambda msg: self._state.on_error(self, msg))
        backend.position_changed.connect(self.position_changed.emit)
        backend.duration_changed.connect(self.duration_changed.emit)

    # ------------------------------------------------------------ чтение ---
    @property
    def state(self) -> PlayerState:
        return self._state

    @property
    def current_track(self) -> Track | None:
        return self._track

    @property
    def queue(self) -> list[Track]:
        return list(self._queue)

    # ------------------------------------- действия (делегируются состоянию) ---
    def play(self) -> None:
        self._state.play(self)

    def pause(self) -> None:
        self._state.pause(self)

    def stop(self) -> None:
        self._state.stop(self)

    def toggle(self) -> None:
        self._state.toggle(self)

    def seek(self, ms: int) -> None:
        if self._state.can_seek:
            self.backend.set_position(max(0, int(ms)))

    def set_volume(self, percent: int) -> None:
        self.backend.set_volume(max(0, min(100, int(percent))))

    # ------------------------------------------------ треки и очередь ---
    def play_track(self, track: Track, queue: list[Track] | None = None) -> None:
        """Начать воспроизведение track. queue — список, по которому работают «вперёд/назад»."""
        if queue is not None:
            self._queue = list(queue)
            self.queue_changed.emit()
        self._select_and_play(track)

    def set_queue(self, tracks: list[Track]) -> None:
        """Обновить очередь (после изменения данных). Играющий трек не прерывается."""
        self._queue = list(tracks)
        self._index = self._find_index(self._track)
        self.queue_changed.emit()

    def next(self) -> None:
        self._step(+1)

    def previous(self) -> None:
        self._step(-1)

    def remove_track(self, track_id: int) -> None:
        """Трек удалён из библиотеки: убрать из очереди; если он играл — остановить."""
        self._queue = [t for t in self._queue if t.id != track_id]
        if self._track is not None and self._track.id == track_id:
            self._state.stop(self)
            self.backend.clear_source()
            self._loaded_path = None
            self._track = None
            self._index = -1
            self.track_changed.emit(None)
        else:
            self._index = self._find_index(self._track)
        self.queue_changed.emit()

    def shutdown(self) -> None:
        self._state.stop(self)

    # ---------------------------- API для объектов-состояний (не для интерфейса) ---
    def set_state(self, new_state: PlayerState) -> None:
        if type(new_state) is type(self._state):
            return
        self._state = new_state
        self.state_changed.emit(new_state)

    def adopt_backend_status(self, status: PlaybackStatus) -> None:
        """Привести состояние контекста к реальному состоянию плеера."""
        if status is not self._state.status:
            self.set_state(state_for(status))

    def notify(self, message: str) -> None:
        self.message.emit(message)

    def fail(self, message: str) -> None:
        """Ошибка воспроизведения: остановиться, сбросить загруженный источник, сообщить."""
        self._loaded_path = None
        self.backend.stop()
        self.set_state(StoppedState())
        self.error.emit(message)

    def prepare_current_track(self) -> bool:
        track = self._track
        if track is None:
            return False
        if not self._file_exists(track.path):
            self.fail(f"Файл не найден: {track.path}")
            return False
        if self._loaded_path != track.path:
            self.backend.load(track.path)
            self._loaded_path = track.path
        return True

    def finish_current_track(self) -> None:
        """Трек доигран: перейти к следующему в очереди либо остановиться."""
        nxt = self._index + 1
        if self._index >= 0 and nxt < len(self._queue):
            self._select_and_play(self._queue[nxt])
            return
        self.backend.stop()
        self.set_state(StoppedState())
        self.notify("Очередь завершена.")

    # ------------------------------------------------------------ внутреннее ---
    def _find_index(self, track: Track | None) -> int:
        if track is None:
            return -1
        for i, item in enumerate(self._queue):
            if item.id == track.id:
                return i
        return -1

    def _select_and_play(self, track: Track) -> None:
        self._state.stop(self)               # остановка текущего (если играл/на паузе)
        self._track = track
        self._index = self._find_index(track)
        self.track_changed.emit(track)
        self.position_changed.emit(0)
        self._state.play(self)               # состояние Stopped: загрузит и запустит

    def _step(self, direction: int) -> None:
        if not self._queue:
            self.notify("Очередь пуста.")
            return
        n = len(self._queue)
        if self._index < 0:
            target = 0 if direction > 0 else n - 1
        else:
            target = (self._index + direction) % n
        self._select_and_play(self._queue[target])
