"""CQRS — сторона ЗАПИСИ.

Команда — неизменяемый объект с намерением («добавить трек», «переименовать
плейлист»). Её исполняет CommandHandler, единственный код в приложении, который
изменяет данные. Результат чтения команды не возвращают; исключение — id
созданной записи (удобно интерфейсу).
"""
from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path

from .database import Database
from .errors import (
    DuplicatePlaylistError, DuplicateTrackError, InvalidPlaylistNameError,
    InvalidTrackError, PlaylistNotFoundError, TrackNotFoundError,
)
from .metadata import guess_title_artist
from .models import SUPPORTED_EXTENSIONS


# ---------------------------------------------------------------- команды ---
@dataclass(frozen=True)
class AddTrack:
    file_path: str
    title: str | None = None
    artist: str | None = None


@dataclass(frozen=True)
class RemoveTrack:
    track_id: int


@dataclass(frozen=True)
class CreatePlaylist:
    name: str


@dataclass(frozen=True)
class RenamePlaylist:
    playlist_id: int
    new_name: str


@dataclass(frozen=True)
class DeletePlaylist:
    playlist_id: int


@dataclass(frozen=True)
class AddTrackToPlaylist:
    playlist_id: int
    track_id: int


@dataclass(frozen=True)
class RemoveTrackFromPlaylist:
    playlist_id: int
    track_id: int


# ------------------------------------------------------------ обработчик ---
class CommandHandler:
    """Исполняет команды. Каждая команда выполняется в одной транзакции."""

    def __init__(self, database: Database) -> None:
        self._conn = database.write
        self._routes = {
            AddTrack: self._add_track,
            RemoveTrack: self._remove_track,
            CreatePlaylist: self._create_playlist,
            RenamePlaylist: self._rename_playlist,
            DeletePlaylist: self._delete_playlist,
            AddTrackToPlaylist: self._add_track_to_playlist,
            RemoveTrackFromPlaylist: self._remove_track_from_playlist,
        }

    def execute(self, command):
        try:
            route = self._routes[type(command)]
        except KeyError:
            raise TypeError(f"Неизвестная команда: {type(command).__name__}") from None
        with self._conn:  # commit при успехе, rollback при исключении
            return route(command)

    # -- треки
    def _add_track(self, cmd: AddTrack) -> int:
        path = Path(cmd.file_path)
        if not path.is_file():
            raise InvalidTrackError(f"Файл не найден: {path}")
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise InvalidTrackError(f"Формат «{path.suffix}» не поддерживается: {path.name}")
        resolved = str(path.resolve())
        guessed_title, guessed_artist = guess_title_artist(resolved)
        title = (cmd.title or "").strip() or guessed_title
        artist = (cmd.artist or "").strip() or guessed_artist
        try:
            cursor = self._conn.execute(
                "INSERT INTO tracks(title, artist, path) VALUES (?, ?, ?)",
                (title, artist, resolved),
            )
        except sqlite3.IntegrityError:
            raise DuplicateTrackError(f"Уже в библиотеке: {path.name}") from None
        return cursor.lastrowid

    def _remove_track(self, cmd: RemoveTrack) -> None:
        # Связи с плейлистами удаляет каскад (PRAGMA foreign_keys = ON).
        cursor = self._conn.execute("DELETE FROM tracks WHERE id = ?", (cmd.track_id,))
        if cursor.rowcount == 0:
            raise TrackNotFoundError("Трек не найден.")

    # -- плейлисты
    def _validated_name(self, name: str, ignore_id: int | None = None) -> str:
        name = (name or "").strip()
        if not name:
            raise InvalidPlaylistNameError("Название плейлиста не может быть пустым.")
        wanted = name.casefold()
        for row in self._conn.execute("SELECT id, name FROM playlists"):
            if row["id"] != ignore_id and row["name"].casefold() == wanted:
                raise DuplicatePlaylistError(f"Плейлист «{row['name']}» уже существует.")
        return name

    def _require_playlist(self, playlist_id: int) -> None:
        if self._conn.execute("SELECT 1 FROM playlists WHERE id = ?", (playlist_id,)).fetchone() is None:
            raise PlaylistNotFoundError("Плейлист не найден.")

    def _create_playlist(self, cmd: CreatePlaylist) -> int:
        name = self._validated_name(cmd.name)
        return self._conn.execute("INSERT INTO playlists(name) VALUES (?)", (name,)).lastrowid

    def _rename_playlist(self, cmd: RenamePlaylist) -> None:
        self._require_playlist(cmd.playlist_id)
        name = self._validated_name(cmd.new_name, ignore_id=cmd.playlist_id)
        self._conn.execute("UPDATE playlists SET name = ? WHERE id = ?", (name, cmd.playlist_id))

    def _delete_playlist(self, cmd: DeletePlaylist) -> None:
        self._require_playlist(cmd.playlist_id)
        self._conn.execute("DELETE FROM playlists WHERE id = ?", (cmd.playlist_id,))

    def _add_track_to_playlist(self, cmd: AddTrackToPlaylist) -> None:
        self._require_playlist(cmd.playlist_id)
        if self._conn.execute("SELECT 1 FROM tracks WHERE id = ?", (cmd.track_id,)).fetchone() is None:
            raise TrackNotFoundError("Трек не найден.")
        # Повторное добавление того же трека — не ошибка: результат тот же.
        self._conn.execute(
            "INSERT OR IGNORE INTO playlist_tracks(playlist_id, track_id) VALUES (?, ?)",
            (cmd.playlist_id, cmd.track_id),
        )

    def _remove_track_from_playlist(self, cmd: RemoveTrackFromPlaylist) -> None:
        self._conn.execute(
            "DELETE FROM playlist_tracks WHERE playlist_id = ? AND track_id = ?",
            (cmd.playlist_id, cmd.track_id),
        )
