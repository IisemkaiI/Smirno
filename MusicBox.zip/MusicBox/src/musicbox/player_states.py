"""Паттерн State: состояния плеера.

Контекст (PlaybackController) не содержит ветвлений «если играет — то…».
Каждое действие он делегирует текущему объекту-состоянию, а состояние само
решает: выполнить действие, проигнорировать его и в какое состояние перейти.
Состояние также сообщает, какие действия доступны (can_*) — по этим флагам
интерфейс включает и выключает кнопки.

Состояния реагируют не только на команды пользователя, но и на события
медиа-бэкенда (on_backend_state / on_end_of_media / on_error), поэтому
внутреннее состояние остаётся согласованным с реальным QMediaPlayer.
"""
from __future__ import annotations

from enum import Enum


class PlaybackStatus(Enum):
    STOPPED = "stopped"
    PLAYING = "playing"
    PAUSED = "paused"


class PlayerState:
    status: PlaybackStatus
    label = ""
    can_play = False    # доступна ли кнопка «Воспроизвести»
    can_pause = False
    can_stop = False
    can_seek = False

    # -- действия пользователя
    def play(self, ctx) -> None:
        raise NotImplementedError

    def pause(self, ctx) -> None:
        """По умолчанию пауза в этом состоянии недопустима и игнорируется."""

    def stop(self, ctx) -> None:
        """По умолчанию стоп в этом состоянии недопустим и игнорируется."""

    def toggle(self, ctx) -> None:
        """Кнопка «играть/пауза»: в состоянии Playing ставит на паузу, иначе играет."""
        self.play(ctx)

    # -- события бэкенда
    def on_backend_state(self, ctx, status: PlaybackStatus) -> None:
        """Реальный QMediaPlayer сменил состояние (например, внешне остановлен)."""
        ctx.adopt_backend_status(status)

    def on_end_of_media(self, ctx) -> None:
        """Трек доиграл до конца. Вне состояния Playing такого быть не должно."""

    def on_error(self, ctx, message: str) -> None:
        ctx.fail(message)


class StoppedState(PlayerState):
    status = PlaybackStatus.STOPPED
    label = "Остановлено"
    can_play = True

    def play(self, ctx) -> None:
        if ctx.current_track is None:
            ctx.notify("Выберите трек для воспроизведения.")
            return
        if not ctx.prepare_current_track():   # файла нет — ошибка уже опубликована
            return
        ctx.backend.play()
        ctx.set_state(PlayingState())


class PlayingState(PlayerState):
    status = PlaybackStatus.PLAYING
    label = "Воспроизведение"
    can_pause = True
    can_stop = True
    can_seek = True

    def play(self, ctx) -> None:
        pass  # уже играет

    def pause(self, ctx) -> None:
        ctx.backend.pause()
        ctx.set_state(PausedState())

    def stop(self, ctx) -> None:
        ctx.backend.stop()
        ctx.set_state(StoppedState())

    def toggle(self, ctx) -> None:
        self.pause(ctx)

    def on_end_of_media(self, ctx) -> None:
        ctx.finish_current_track()   # автопереход к следующему или остановка


class PausedState(PlayerState):
    status = PlaybackStatus.PAUSED
    label = "Пауза"
    can_play = True
    can_stop = True
    can_seek = True

    def play(self, ctx) -> None:
        ctx.backend.play()
        ctx.set_state(PlayingState())

    def stop(self, ctx) -> None:
        ctx.backend.stop()
        ctx.set_state(StoppedState())

    def on_end_of_media(self, ctx) -> None:
        ctx.finish_current_track()


_BY_STATUS = {
    PlaybackStatus.STOPPED: StoppedState,
    PlaybackStatus.PLAYING: PlayingState,
    PlaybackStatus.PAUSED: PausedState,
}


def state_for(status: PlaybackStatus) -> PlayerState:
    return _BY_STATUS[status]()
