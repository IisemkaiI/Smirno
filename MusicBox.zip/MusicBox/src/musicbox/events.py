"""Минимальный механизм подписки на события без зависимости от Qt.

Нужен, чтобы логика плеера (состояния, очередь) работала и тестировалась без
графической библиотеки. Qt-слой лишь вызывает emit() из своих сигналов.
"""
from __future__ import annotations

from typing import Callable


class Event:
    def __init__(self) -> None:
        self._handlers: list[Callable] = []

    def connect(self, handler: Callable) -> None:
        self._handlers.append(handler)

    def emit(self, *args) -> None:
        for handler in list(self._handlers):
            handler(*args)
