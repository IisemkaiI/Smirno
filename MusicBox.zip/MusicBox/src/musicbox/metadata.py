"""Определение названия и исполнителя по имени файла.

Теги ID3/Vorbis не читаются (это потребовало бы отдельной библиотеки), поэтому
используется соглашение «Исполнитель - Название.ext».
"""
from __future__ import annotations

from pathlib import Path

from .models import UNKNOWN_ARTIST


def guess_title_artist(file_path: str) -> tuple[str, str]:
    stem = Path(file_path).stem.strip()
    if " - " in stem:
        artist, title = (part.strip() for part in stem.split(" - ", 1))
        if artist and title:
            return title, artist
    return stem or "Без названия", UNKNOWN_ARTIST
