"""Чистые функции форматирования для интерфейса."""
from __future__ import annotations


def format_time(ms: int) -> str:
    """Миллисекунды -> «м:сс» либо «ч:мм:сс»."""
    total = max(0, int(ms)) // 1000
    hours, rest = divmod(total, 3600)
    minutes, seconds = divmod(rest, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"
