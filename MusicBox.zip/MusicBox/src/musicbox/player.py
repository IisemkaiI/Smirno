"""Адаптер Qt Multimedia под интерфейс AudioBackend.

Единственный модуль, который напрямую работает с QMediaPlayer. Он переводит
сигналы Qt в события Event, которые слушает PlaybackController.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, QTimer, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

from .events import Event
from .player_states import PlaybackStatus

_QT_TO_STATUS = {
    QMediaPlayer.PlaybackState.StoppedState: PlaybackStatus.STOPPED,
    QMediaPlayer.PlaybackState.PlayingState: PlaybackStatus.PLAYING,
    QMediaPlayer.PlaybackState.PausedState: PlaybackStatus.PAUSED,
}


class QtAudioBackend(QObject):
    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.state_changed = Event()
        self.ended = Event()
        self.error = Event()
        self.position_changed = Event()
        self.duration_changed = Event()

        self._audio = QAudioOutput(self)
        self._media = QMediaPlayer(self)
        self._media.setAudioOutput(self._audio)
        self._end_reported = False

        # Qt может прислать «остановлено» и «конец трека» в любом порядке. Чтобы
        # автопереход не терялся, смену состояния сверяем с реальностью чуть позже.
        self._reconcile_timer = QTimer(self)
        self._reconcile_timer.setSingleShot(True)
        self._reconcile_timer.setInterval(40)
        self._reconcile_timer.timeout.connect(self._reconcile)

        self._media.playbackStateChanged.connect(lambda _s: self._reconcile_timer.start())
        self._media.mediaStatusChanged.connect(self._on_media_status)
        self._media.errorOccurred.connect(self._on_error)
        self._media.positionChanged.connect(lambda ms: self.position_changed.emit(int(ms)))
        self._media.durationChanged.connect(lambda ms: self.duration_changed.emit(int(ms)))

    # -- команды плеера
    def load(self, path: str) -> None:
        self._end_reported = False
        self._media.setSource(QUrl.fromLocalFile(path))

    def clear_source(self) -> None:
        self._end_reported = False
        self._media.setSource(QUrl())

    def play(self) -> None:
        self._end_reported = False
        self._media.play()

    def pause(self) -> None:
        self._media.pause()

    def stop(self) -> None:
        self._media.stop()

    def set_position(self, ms: int) -> None:
        self._media.setPosition(int(ms))

    def set_volume(self, percent: int) -> None:
        self._audio.setVolume(max(0, min(100, percent)) / 100.0)

    # -- события Qt
    def _on_media_status(self, status) -> None:
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._report_end()

    def _report_end(self) -> None:
        if not self._end_reported:
            self._end_reported = True
            self.ended.emit()

    def _on_error(self, error, error_string: str = "") -> None:
        if error == QMediaPlayer.Error.NoError:
            return
        self.error.emit(error_string or "Не удалось воспроизвести файл.")

    def _actual_status(self) -> PlaybackStatus:
        return _QT_TO_STATUS[self._media.playbackState()]

    def _reconcile(self) -> None:
        if (self._actual_status() is PlaybackStatus.STOPPED
                and self._media.mediaStatus() == QMediaPlayer.MediaStatus.EndOfMedia):
            self._report_end()   # «стоп» пришёл раньше «конца трека» — это конец трека
        # Читаем состояние заново: обработка конца трека могла запустить следующий.
        self.state_changed.emit(self._actual_status())
