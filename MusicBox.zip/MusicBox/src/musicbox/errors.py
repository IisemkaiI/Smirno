"""Доменные ошибки. Тексты предназначены для показа пользователю."""


class MusicBoxError(Exception):
    """Базовая ошибка приложения."""


class InvalidTrackError(MusicBoxError):
    """Файл нельзя добавить в библиотеку (нет файла, неподдерживаемый формат)."""


class DuplicateTrackError(MusicBoxError):
    """Трек с таким путём уже есть в библиотеке."""


class TrackNotFoundError(MusicBoxError):
    pass


class PlaylistNotFoundError(MusicBoxError):
    pass


class InvalidPlaylistNameError(MusicBoxError):
    pass


class DuplicatePlaylistError(MusicBoxError):
    """Плейлист с таким названием уже существует."""
