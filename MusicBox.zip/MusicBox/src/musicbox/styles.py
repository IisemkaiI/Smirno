"""Тёмная фиолетовая тема (QSS). Применяется ко всему QApplication,
поэтому оформляются и диалоги, и контекстные меню."""

APP_STYLE = """
* { font-family: 'Segoe UI', 'Inter', 'Noto Sans', sans-serif; font-size: 14px; outline: 0; }
QMainWindow, QDialog, QMessageBox, QInputDialog { background: #0f1117; }
QWidget { color: #e6e8ef; }
QMainWindow > QWidget { background: #0f1117; }
QToolTip { background: #1b1e27; color: #e6e8ef; border: 1px solid #343a4a; padding: 5px 8px; }

/* ---------- боковая панель ---------- */
QFrame#sidebar { background: #0b0d12; border-right: 1px solid #1d212b; }
QLabel#brand { font-size: 22px; font-weight: 700; color: #b69cff; padding: 4px 6px 12px 6px; }
QLabel#sectionTitle { color: #6f7688; font-size: 11px; font-weight: 700; letter-spacing: 1px; padding: 8px 8px 2px 8px; }
QListWidget#sources { background: transparent; border: none; }
QListWidget#sources::item { padding: 10px 12px; border-radius: 8px; color: #b8bdcc; margin: 1px 0; }
QListWidget#sources::item:hover { background: #151925; }
QListWidget#sources::item:selected { background: #2a2250; color: #ffffff; }

/* ---------- основная область ---------- */
QLabel#viewTitle { font-size: 24px; font-weight: 700; color: #ffffff; }
QLabel#viewSubtitle { color: #7b8296; }
QLineEdit { background: #171a23; border: 1px solid #2a2f3d; border-radius: 10px; padding: 9px 12px; color: #f1f2f7; selection-background-color: #6d4be0; }
QLineEdit:focus { border: 1px solid #8b5cf6; }

QTreeWidget { background: #12151d; border: 1px solid #1f2430; border-radius: 12px; color: #d7dae4; }
QTreeWidget::item { padding: 9px 6px; border: none; }
QTreeWidget::item:hover { background: #181c27; }
QTreeWidget::item:selected { background: #2a2250; color: #ffffff; }
QHeaderView { background: transparent; }
QHeaderView::section { background: #12151d; color: #6f7688; border: none; border-bottom: 1px solid #1f2430; padding: 9px 6px; font-size: 12px; font-weight: 600; }
QLabel#emptyHint { color: #7b8296; font-size: 15px; background: #12151d; border: 1px dashed #2a2f3d; border-radius: 12px; padding: 30px; }

/* ---------- кнопки ---------- */
QPushButton { background: #1b1f2b; border: 1px solid #2a2f3d; border-radius: 10px; padding: 9px 16px; color: #e6e8ef; }
QPushButton:hover { background: #252a3a; border-color: #394058; }
QPushButton:pressed { background: #2e344a; }
QPushButton:disabled { color: #4d5364; background: #151821; border-color: #1f2430; }
QPushButton#accent { background: #7c4dff; border: none; font-weight: 600; color: #ffffff; }
QPushButton#accent:hover { background: #8d63ff; }
QPushButton#accent:pressed { background: #6a3de8; }
QPushButton#ghost { background: transparent; border: 1px dashed #343a4a; color: #b8bdcc; }
QPushButton#ghost:hover { background: #151925; border-color: #8b5cf6; color: #ffffff; }
QPushButton#transport { background: transparent; border: none; border-radius: 20px; font-size: 18px; color: #d7dae4; padding: 0; }
QPushButton#transport:hover { background: #1f2432; }
QPushButton#transport:disabled { color: #3d4252; background: transparent; }
QPushButton#playButton { background: #7c4dff; border: none; border-radius: 24px; font-size: 18px; color: #ffffff; padding: 0; }
QPushButton#playButton:hover { background: #8d63ff; }
QPushButton#playButton:pressed { background: #6a3de8; }

/* ---------- панель плеера ---------- */
QFrame#playerBar { background: #0b0d12; border-top: 1px solid #1d212b; }
QLabel#npTitle { font-size: 15px; font-weight: 600; color: #ffffff; }
QLabel#npArtist { color: #8a90a3; }
QLabel#npState { color: #b69cff; font-size: 12px; font-weight: 600; }
QLabel#time { color: #8a90a3; font-size: 12px; }
QLabel#volumeIcon { color: #8a90a3; font-size: 16px; }

QSlider::groove:horizontal { height: 4px; background: #2a2f3d; border-radius: 2px; }
QSlider::sub-page:horizontal { background: #8b5cf6; border-radius: 2px; }
QSlider::handle:horizontal { background: #f1ecff; width: 12px; height: 12px; margin: -4px 0; border-radius: 6px; }
QSlider::handle:horizontal:hover { background: #ffffff; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }
QSlider:disabled::sub-page:horizontal { background: #3a3f50; }
QSlider:disabled::handle:horizontal { background: #3a3f50; }

/* ---------- прочее ---------- */
QStatusBar { background: #0b0d12; color: #8a90a3; border-top: 1px solid #1d212b; }
QStatusBar::item { border: none; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #2a2f3d; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #3a4156; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QMenu { background: #181b25; border: 1px solid #2a2f3d; border-radius: 10px; padding: 6px; }
QMenu::item { padding: 8px 22px; border-radius: 6px; color: #e6e8ef; }
QMenu::item:selected { background: #352b66; }
QMenu::item:disabled { color: #566; }
QMenu::separator { height: 1px; background: #2a2f3d; margin: 5px 8px; }
"""
