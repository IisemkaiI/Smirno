"""Неизменяемые модели данных, которыми обмениваются слои приложения."""
from __future__ import annotations

from dataclasses import dataclass

UNKNOWN_ARTIST = "Неизвестный исполнитель"

# Расширения, которые принимает команда AddTrack и фильтр диалога выбора файлов.
# Фактическая поддержка зависит от медиа-бэкенда Qt (FFmpeg в PySide6 >= 6.5).
SUPPORTED_EXTENSIONS = (".mp3", ".wav", ".flac", ".ogg", ".opus", ".m4a", ".aac", ".wma")


@dataclass(frozen=True)
class Track:
    id: int
    title: str
    artist: str
    path: str


@dataclass(frozen=True)
class Playlist:
    id: int
    name: str
    track_count: int = 0
