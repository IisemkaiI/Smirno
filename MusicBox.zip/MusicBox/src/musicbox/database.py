"""Слой хранения SQLite.

Для CQRS у базы два соединения:
  * ``write`` — используется только обработчиками команд;
  * ``read``  — используется только обработчиками запросов, на уровне SQLite
    включён ``PRAGMA query_only``, поэтому запрос физически не может изменить данные.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS tracks (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    title  TEXT NOT NULL,
    artist TEXT NOT NULL,
    path   TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS playlists (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS playlist_tracks (
    playlist_id INTEGER NOT NULL,
    track_id    INTEGER NOT NULL,
    UNIQUE (playlist_id, track_id),
    FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY (track_id)    REFERENCES tracks(id)    ON DELETE CASCADE
);
"""


def default_db_path() -> Path:
    """~/.musicbox/musicbox.db (путь можно переопределить переменной MUSICBOX_DB)."""
    override = os.environ.get("MUSICBOX_DB")
    if override:
        return Path(override)
    return Path.home() / ".musicbox" / "musicbox.db"


def _casefold_sql(value):
    return value.casefold() if isinstance(value, str) else value


def _casefold_collation(a: str, b: str) -> int:
    a, b = a.casefold(), b.casefold()
    return (a > b) - (a < b)


class Database:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else default_db_path()
        in_memory = str(self.path) == ":memory:"
        if not in_memory:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        target = ":memory:" if in_memory else str(self.path)

        self.write = self._connect(target)
        self.write.execute("PRAGMA foreign_keys = ON")
        self.write.executescript(SCHEMA)
        self.write.commit()

        if in_memory:
            # Отдельное соединение к :memory: видело бы пустую базу.
            self.read = self.write
        else:
            self.read = self._connect(target)
            self.read.execute("PRAGMA query_only = ON")
        # SQLite сравнивает без учёта регистра только ASCII, поэтому кириллицу
        # обрабатываем собственными функцией и сортировкой.
        self.read.create_function("casefold", 1, _casefold_sql, deterministic=True)
        self.read.create_collation("CASEFOLD", _casefold_collation)

    @staticmethod
    def _connect(target: str) -> sqlite3.Connection:
        connection = sqlite3.connect(target)
        connection.row_factory = sqlite3.Row
        return connection

    def close(self) -> None:
        if self.read is not self.write:
            self.read.close()
        self.write.close()
