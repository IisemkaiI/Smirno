"""Главное окно (слой представления).

Окно не обращается к SQLite напрямую и не хранит логику воспроизведения:
  * изменения данных — через команды (CommandHandler.execute);
  * чтение данных — через запросы (QueryHandler.ask);
  * воспроизведение — через PlaybackController (контекст паттерна State),
    состояния кнопок берутся из флагов can_* текущего состояния.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView, QFileDialog, QFrame, QHBoxLayout, QHeaderView, QInputDialog,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox,
    QPushButton, QSizePolicy, QSlider, QStackedWidget, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget,
)

from .commands import (
    AddTrack, AddTrackToPlaylist, CommandHandler, CreatePlaylist, DeletePlaylist,
    RemoveTrack, RemoveTrackFromPlaylist, RenamePlaylist,
)
from .errors import DuplicateTrackError, MusicBoxError
from .formatting import format_time
from .models import SUPPORTED_EXTENSIONS, Track
from .playback import PlaybackController
from .player_states import PlaybackStatus, PlayerState
from .queries import GetPlaylists, GetPlaylistTracks, GetTracks, QueryHandler

LIBRARY = 0       # id «Вся библиотека» (id плейлистов в SQLite начинаются с 1)
NO_SOURCE = -1    # очередь ещё не создана
ROLE_ID = Qt.ItemDataRole.UserRole


class MainWindow(QMainWindow):
    def __init__(self, commands: CommandHandler, queries: QueryHandler, player: PlaybackController):
        super().__init__()
        self.commands = commands
        self.queries = queries
        self.player = player

        self._view_source = LIBRARY      # что показано в таблице
        self._queue_source = NO_SOURCE   # из какого источника собрана очередь плеера
        self._view_tracks: list[Track] = []
        self._playlists = []
        self._last_dir = str(Path.home())

        self.setWindowTitle("MusicBox")
        self.resize(1080, 700)
        self.setMinimumSize(860, 560)
        self.setAcceptDrops(True)
        self._build_ui()
        self._connect_player()
        self.player.set_volume(self.volume_slider.value())
        self._on_state_changed(self.player.state)
        self._on_track_changed(None)
        self.refresh()

    # ---------------------------------------------------------- построение ---
    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        body = QHBoxLayout()
        body.setSpacing(0)
        body.addWidget(self._build_sidebar())
        body.addWidget(self._build_content(), 1)
        outer.addLayout(body, 1)
        outer.addWidget(self._build_player_bar())

    def _build_sidebar(self) -> QWidget:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(250)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(14, 18, 14, 14)
        layout.setSpacing(4)

        brand = QLabel("♫  MusicBox")
        brand.setObjectName("brand")
        layout.addWidget(brand)
        title = QLabel("МЕДИАТЕКА")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        self.source_list = QListWidget()
        self.source_list.setObjectName("sources")
        self.source_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.source_list.currentRowChanged.connect(self._on_source_row_changed)
        self.source_list.customContextMenuRequested.connect(self._show_playlist_menu)
        layout.addWidget(self.source_list, 1)

        new_playlist = QPushButton("＋  Новый плейлист")
        new_playlist.setObjectName("ghost")
        new_playlist.setCursor(Qt.CursorShape.PointingHandCursor)
        new_playlist.clicked.connect(self._create_playlist)
        layout.addWidget(new_playlist)
        return sidebar

    def _build_content(self) -> QWidget:
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(28, 24, 28, 16)
        layout.setSpacing(14)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        self.view_title = QLabel("Вся библиотека")
        self.view_title.setObjectName("viewTitle")
        self.view_subtitle = QLabel("")
        self.view_subtitle.setObjectName("viewSubtitle")
        titles.addWidget(self.view_title)
        titles.addWidget(self.view_subtitle)
        head.addLayout(titles, 1)
        self.add_button = QPushButton("＋  Добавить музыку")
        self.add_button.setObjectName("accent")
        self.add_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_button.clicked.connect(self._add_files)
        head.addWidget(self.add_button, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addLayout(head)

        self.search = QLineEdit()
        self.search.setPlaceholderText("🔍  Поиск по названию или исполнителю…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._reload_tracks)
        layout.addWidget(self.search)

        self.track_tree = QTreeWidget()
        self.track_tree.setHeaderLabels(["#", "Название", "Исполнитель"])
        self.track_tree.setRootIsDecorated(False)
        self.track_tree.setIndentation(0)
        self.track_tree.setUniformRowHeights(True)
        self.track_tree.setAllColumnsShowFocus(True)
        self.track_tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.track_tree.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.track_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        header = self.track_tree.header()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setStretchLastSection(False)
        self.track_tree.setColumnWidth(0, 52)
        self.track_tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.track_tree.customContextMenuRequested.connect(self._show_track_menu)
        space = QShortcut(QKeySequence("Space"), self.track_tree)
        space.setContext(Qt.ShortcutContext.WidgetShortcut)
        space.activated.connect(self._toggle_play)

        self.empty_hint = QLabel(
            "Здесь пока пусто.\n\nНажмите «Добавить музыку» или перетащите аудиофайлы в окно."
        )
        self.empty_hint.setObjectName("emptyHint")
        self.empty_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.stack = QStackedWidget()
        self.stack.addWidget(self.track_tree)   # 0
        self.stack.addWidget(self.empty_hint)   # 1
        layout.addWidget(self.stack, 1)
        return content

    def _build_player_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("playerBar")
        bar.setFixedHeight(96)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(24, 10, 24, 10)
        layout.setSpacing(20)

        # слева — что играет
        now = QVBoxLayout()
        now.setSpacing(2)
        self.np_title = QLabel("Ничего не выбрано")
        self.np_title.setObjectName("npTitle")
        self.np_artist = QLabel("")
        self.np_artist.setObjectName("npArtist")
        self.np_state = QLabel("")
        self.np_state.setObjectName("npState")
        for label in (self.np_title, self.np_artist, self.np_state):
            label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            now.addWidget(label)
        layout.addLayout(now, 3)

        # по центру — кнопки и перемотка
        center = QVBoxLayout()
        center.setSpacing(4)
        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addStretch()
        self.prev_button = self._transport_button("⏮", "Предыдущий трек", 40, "transport")
        self.stop_button = self._transport_button("■", "Остановить", 40, "transport")
        self.play_button = self._transport_button("▶", "Воспроизвести", 48, "playButton")
        self.next_button = self._transport_button("⏭", "Следующий трек", 40, "transport")
        self.prev_button.clicked.connect(self._previous)
        self.stop_button.clicked.connect(self.player.stop)
        self.play_button.clicked.connect(self._toggle_play)
        self.next_button.clicked.connect(self._next)
        for b in (self.prev_button, self.stop_button, self.play_button, self.next_button):
            buttons.addWidget(b)
        buttons.addStretch()
        center.addLayout(buttons)

        seek_row = QHBoxLayout()
        seek_row.setSpacing(8)
        self.elapsed_label = QLabel("0:00")
        self.elapsed_label.setObjectName("time")
        self.total_label = QLabel("0:00")
        self.total_label.setObjectName("time")
        self.seek_slider = QSlider(Qt.Orientation.Horizontal)
        self.seek_slider.setRange(0, 0)
        self.seek_slider.sliderMoved.connect(lambda v: self.elapsed_label.setText(format_time(v)))
        self.seek_slider.sliderReleased.connect(lambda: self.player.seek(self.seek_slider.value()))
        seek_row.addWidget(self.elapsed_label)
        seek_row.addWidget(self.seek_slider, 1)
        seek_row.addWidget(self.total_label)
        center.addLayout(seek_row)
        layout.addLayout(center, 5)

        # справа — громкость
        volume = QHBoxLayout()
        volume.setSpacing(8)
        volume.addStretch()
        icon = QLabel("🔈")
        icon.setObjectName("volumeIcon")
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(70)
        self.volume_slider.setFixedWidth(130)
        self.volume_slider.setToolTip("Громкость")
        self.volume_slider.valueChanged.connect(self.player.set_volume)
        volume.addWidget(icon)
        volume.addWidget(self.volume_slider)
        layout.addLayout(volume, 2)
        return bar

    @staticmethod
    def _transport_button(text: str, tooltip: str, size: int, object_name: str) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName(object_name)
        button.setToolTip(tooltip)
        button.setFixedSize(size, size)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        return button

    def _connect_player(self) -> None:
        p = self.player
        p.state_changed.connect(self._on_state_changed)
        p.track_changed.connect(self._on_track_changed)
        p.position_changed.connect(self._on_position)
        p.duration_changed.connect(self._on_duration)
        p.error.connect(lambda msg: self._flash("⚠  " + msg, 10000))
        p.message.connect(self._flash)

    # ------------------------------------------------- события плеера (State) ---
    def _on_state_changed(self, state: PlayerState) -> None:
        """Интерфейс целиком определяется текущим состоянием и его флагами can_*."""
        self.play_button.setText("❚❚" if state.can_pause else "▶")
        self.play_button.setToolTip("Пауза" if state.can_pause else "Воспроизвести")
        self.stop_button.setEnabled(state.can_stop)
        self.seek_slider.setEnabled(state.can_seek)
        self.np_state.setText(state.label.upper() if self.player.current_track else "")
        self._update_markers()

    def _on_track_changed(self, track: Track | None) -> None:
        if track is None:
            self.np_title.setText("Ничего не выбрано")
            self.np_artist.setText("")
            self.np_state.setText("")
            self.setWindowTitle("MusicBox")
        else:
            self.np_title.setText(track.title)
            self.np_artist.setText(track.artist)
            self.np_state.setText(self.player.state.label.upper())
            self.setWindowTitle(f"{track.title} — {track.artist} · MusicBox")
        self.seek_slider.setRange(0, 0)
        self.seek_slider.setValue(0)
        self.elapsed_label.setText("0:00")
        self.total_label.setText("0:00")
        self._update_markers()
        if track is not None:
            self._select_in_view(track)

    def _select_in_view(self, track: Track) -> None:
        """Выделение следует за играющим треком (в том числе при автопереходе)."""
        for row in range(self.track_tree.topLevelItemCount()):
            item = self.track_tree.topLevelItem(row)
            if item.data(0, ROLE_ID) == track.id:
                self.track_tree.setCurrentItem(item)
                self.track_tree.scrollToItem(item)
                return

    def _on_duration(self, ms: int) -> None:
        self.seek_slider.setRange(0, max(0, ms))
        self.total_label.setText(format_time(ms))

    def _on_position(self, ms: int) -> None:
        if self.seek_slider.isSliderDown():
            return  # пользователь сейчас тянет ползунок
        self.seek_slider.setValue(ms)
        self.elapsed_label.setText(format_time(ms))

    def _flash(self, text: str, timeout_ms: int = 6000) -> None:
        self.statusBar().showMessage(text, timeout_ms)

    # ------------------------------------------------------------ обновление ---
    def refresh(self) -> None:
        """Перечитать данные запросами и обновить все представления."""
        self._reload_playlists()
        self._reload_tracks()
        self._sync_queue()

    def _source_tracks(self, source: int, text: str = "") -> list[Track]:
        if source == LIBRARY:
            return self.queries.ask(GetTracks(text))
        return self.queries.ask(GetPlaylistTracks(source, text))

    def _reload_playlists(self) -> None:
        self._playlists = self.queries.ask(GetPlaylists())
        known = {p.id for p in self._playlists}
        if self._view_source != LIBRARY and self._view_source not in known:
            self._view_source = LIBRARY
        if self._queue_source not in (LIBRARY, NO_SOURCE) and self._queue_source not in known:
            self._queue_source = NO_SOURCE   # плейлист удалён: очередь освобождаем

        total = len(self.queries.ask(GetTracks()))
        self.source_list.blockSignals(True)
        self.source_list.clear()
        entries = [(LIBRARY, f"♫   Вся библиотека   ·   {total}")]
        entries += [(p.id, f"☰   {p.name}   ·   {p.track_count}") for p in self._playlists]
        selected_row = 0
        for row, (source_id, text) in enumerate(entries):
            item = QListWidgetItem(text)
            item.setData(ROLE_ID, source_id)
            self.source_list.addItem(item)
            if source_id == self._view_source:
                selected_row = row
        self.source_list.setCurrentRow(selected_row)
        self.source_list.blockSignals(False)

    def _reload_tracks(self, *_args) -> None:
        text = self.search.text()
        self._view_tracks = self._source_tracks(self._view_source, text)
        if self._view_source == LIBRARY:
            self.view_title.setText("Вся библиотека")
        else:
            name = next((p.name for p in self._playlists if p.id == self._view_source), "")
            self.view_title.setText(name)
        count = len(self._view_tracks)
        self.view_subtitle.setText(
            f"Найдено: {count}" if text.strip() else f"Треков: {count}"
        )

        self.track_tree.clear()
        for number, track in enumerate(self._view_tracks, start=1):
            item = QTreeWidgetItem([str(number), track.title, track.artist])
            item.setData(0, ROLE_ID, track.id)
            item.setToolTip(1, track.path)
            self.track_tree.addTopLevelItem(item)
        if self._view_tracks or text.strip():
            self.stack.setCurrentIndex(0)
        else:
            self.empty_hint.setText(
                "Здесь пока пусто.\n\nНажмите «Добавить музыку» или перетащите аудиофайлы в окно."
                if self._view_source == LIBRARY else
                "В плейлисте пока нет треков.\n\nНажмите правой кнопкой на треке в библиотеке →\n«Добавить в плейлист»."
            )
            self.stack.setCurrentIndex(1)
        self._update_markers()

    def _sync_queue(self) -> None:
        """Очередь плеера = полный источник, из которого запущен трек (не результат поиска)."""
        if self._queue_source != NO_SOURCE:
            self.player.set_queue(self._source_tracks(self._queue_source))

    def _update_markers(self) -> None:
        """В первой колонке: ▶ / ❚❚ у текущего трека, иначе номер строки."""
        current = self.player.current_track
        state = self.player.state
        for row in range(self.track_tree.topLevelItemCount()):
            item = self.track_tree.topLevelItem(row)
            is_current = current is not None and item.data(0, ROLE_ID) == current.id
            if is_current:
                marker = "▶" if state.status is PlaybackStatus.PLAYING else (
                    "❚❚" if state.status is PlaybackStatus.PAUSED else "■")
            else:
                marker = str(row + 1)
            item.setText(0, marker)
            font = QFont(item.font(1))
            font.setBold(is_current)
            item.setFont(1, font)

    # ------------------------------------------------------------ выбор ---
    def _on_source_row_changed(self, row: int) -> None:
        item = self.source_list.item(row)
        if item is None:
            return
        self._view_source = item.data(ROLE_ID)
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self._reload_tracks()

    def _selected_tracks(self) -> list[Track]:
        by_id = {t.id: t for t in self._view_tracks}
        ids = [i.data(0, ROLE_ID) for i in self.track_tree.selectedItems()]
        return [by_id[i] for i in ids if i in by_id]

    def _on_item_double_clicked(self, item: QTreeWidgetItem, _column: int) -> None:
        track_id = item.data(0, ROLE_ID)
        track = next((t for t in self._view_tracks if t.id == track_id), None)
        if track:
            self._play_from_view(track)

    # --------------------------------------------------------- воспроизведение ---
    def _play_from_view(self, track: Track) -> None:
        self._queue_source = self._view_source
        self.player.play_track(track, self._source_tracks(self._view_source))

    def _ensure_queue(self) -> bool:
        if self.player.queue:
            return True
        tracks = self._source_tracks(self._view_source)
        if not tracks:
            self._flash("Сначала добавьте музыку в библиотеку.")
            return False
        self._queue_source = self._view_source
        self.player.set_queue(tracks)
        return True

    def _toggle_play(self) -> None:
        player = self.player
        selected = self._selected_tracks()
        current = player.current_track
        if (player.state.status is PlaybackStatus.STOPPED and selected
                and (current is None or selected[0].id != current.id)):
            self._play_from_view(selected[0])     # выбрали другой трек и нажали «играть»
            return
        if current is None:
            if self._view_tracks:
                self._play_from_view(self._view_tracks[0])
            else:
                self._flash("Сначала добавьте музыку в библиотеку.")
            return
        player.toggle()

    def _next(self) -> None:
        if self._ensure_queue():
            self.player.next()

    def _previous(self) -> None:
        if self._ensure_queue():
            self.player.previous()

    # ----------------------------------------------- команды (сторона записи) ---
    def _run(self, command):
        """Выполнить команду; ошибку домена показать пользователю. -> (успех, результат)."""
        try:
            return True, self.commands.execute(command)
        except MusicBoxError as exc:
            QMessageBox.warning(self, "MusicBox", str(exc))
            return False, None

    def _add_files(self) -> None:
        pattern = " ".join(f"*{ext}" for ext in SUPPORTED_EXTENSIONS)
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Добавить аудиофайлы", self._last_dir, f"Аудиофайлы ({pattern});;Все файлы (*)"
        )
        if paths:
            self._last_dir = str(Path(paths[0]).parent)
            self._import_paths(paths)

    def _import_paths(self, paths: list[str]) -> None:
        added = duplicates = 0
        problems: list[str] = []
        for path in paths:
            try:
                self.commands.execute(AddTrack(path))
                added += 1
            except DuplicateTrackError:
                duplicates += 1
            except MusicBoxError as exc:
                problems.append(str(exc))
        self.refresh()
        summary = f"Добавлено треков: {added}"
        if duplicates:
            summary += f" · уже были в библиотеке: {duplicates}"
        if problems:
            summary += f" · пропущено: {len(problems)}"
        self._flash(summary)
        if problems:
            QMessageBox.warning(self, "Не все файлы добавлены", "\n".join(problems[:10]))

    def _remove_from_library(self, tracks: list[Track]) -> None:
        names = f"«{tracks[0].title}»" if len(tracks) == 1 else f"треки ({len(tracks)})"
        answer = QMessageBox.question(
            self, "Удаление",
            f"Удалить {names} из библиотеки?\nФайлы на диске останутся нетронутыми.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        for track in tracks:
            ok, _ = self._run(RemoveTrack(track.id))
            if ok:
                self.player.remove_track(track.id)   # остановит воспроизведение, если трек играл
        self.refresh()

    def _remove_from_playlist(self, tracks: list[Track]) -> None:
        for track in tracks:
            self._run(RemoveTrackFromPlaylist(self._view_source, track.id))
        self.refresh()

    def _create_playlist(self) -> int | None:
        name, ok = QInputDialog.getText(self, "Новый плейлист", "Название плейлиста:")
        if not ok:
            return None
        success, playlist_id = self._run(CreatePlaylist(name))
        if success:
            self.refresh()
            return playlist_id
        return None

    def _add_to_playlist(self, playlist_id: int, tracks: list[Track]) -> None:
        for track in tracks:
            self._run(AddTrackToPlaylist(playlist_id, track.id))
        self.refresh()
        name = next((p.name for p in self._playlists if p.id == playlist_id), "плейлист")
        self._flash(f"Добавлено в «{name}»: {len(tracks)}")

    def _add_to_new_playlist(self, tracks: list[Track]) -> None:
        playlist_id = self._create_playlist()
        if playlist_id is not None:
            self._add_to_playlist(playlist_id, tracks)

    def _rename_playlist(self, playlist_id: int, old_name: str) -> None:
        name, ok = QInputDialog.getText(
            self, "Переименовать плейлист", "Новое название:", QLineEdit.EchoMode.Normal, old_name
        )
        if ok and self._run(RenamePlaylist(playlist_id, name))[0]:
            self.refresh()

    def _delete_playlist(self, playlist_id: int, name: str) -> None:
        answer = QMessageBox.question(
            self, "Удаление плейлиста",
            f"Удалить плейлист «{name}»?\nТреки останутся в библиотеке.",
        )
        if answer == QMessageBox.StandardButton.Yes and self._run(DeletePlaylist(playlist_id))[0]:
            self.refresh()

    # ------------------------------------------------------- контекстные меню ---
    def _show_track_menu(self, pos) -> None:
        item = self.track_tree.itemAt(pos)
        if item is not None and not item.isSelected():
            self.track_tree.clearSelection()
            item.setSelected(True)
        tracks = self._selected_tracks()
        if not tracks:
            return
        menu = QMenu(self)
        if len(tracks) == 1:
            menu.addAction("▶   Воспроизвести").triggered.connect(
                lambda _=False, t=tracks[0]: self._play_from_view(t))
            menu.addSeparator()
        sub = menu.addMenu("Добавить в плейлист")
        for playlist in self._playlists:
            sub.addAction(playlist.name).triggered.connect(
                lambda _=False, pid=playlist.id: self._add_to_playlist(pid, tracks))
        if self._playlists:
            sub.addSeparator()
        sub.addAction("＋  Новый плейлист…").triggered.connect(
            lambda _=False: self._add_to_new_playlist(tracks))
        if self._view_source != LIBRARY:
            menu.addAction("Убрать из плейлиста").triggered.connect(
                lambda _=False: self._remove_from_playlist(tracks))
        menu.addSeparator()
        menu.addAction("Удалить из библиотеки…").triggered.connect(
            lambda _=False: self._remove_from_library(tracks))
        menu.exec(self.track_tree.viewport().mapToGlobal(pos))

    def _show_playlist_menu(self, pos) -> None:
        item = self.source_list.itemAt(pos)
        if item is None or item.data(ROLE_ID) == LIBRARY:
            return
        playlist_id = item.data(ROLE_ID)
        name = next((p.name for p in self._playlists if p.id == playlist_id), "")
        menu = QMenu(self)
        menu.addAction("Переименовать…").triggered.connect(
            lambda _=False: self._rename_playlist(playlist_id, name))
        menu.addAction("Удалить плейлист…").triggered.connect(
            lambda _=False: self._delete_playlist(playlist_id, name))
        menu.exec(self.source_list.viewport().mapToGlobal(pos))

    # ---------------------------------------------------- перетаскивание файлов ---
    def dragEnterEvent(self, event) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self._import_paths(paths)

    def closeEvent(self, event) -> None:
        self.player.shutdown()
        super().closeEvent(event)
