"""Сборка приложения: база -> обработчики команд/запросов -> плеер -> окно."""
from __future__ import annotations

import sys


def main() -> int:
    from PySide6.QtWidgets import QApplication

    from .commands import CommandHandler
    from .database import Database
    from .main_window import MainWindow
    from .playback import PlaybackController
    from .player import QtAudioBackend
    from .queries import QueryHandler
    from .styles import APP_STYLE

    app = QApplication(sys.argv)
    app.setApplicationName("MusicBox")
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)

    database = Database()
    backend = QtAudioBackend()
    player = PlaybackController(backend)
    window = MainWindow(CommandHandler(database), QueryHandler(database), player)
    window.show()
    try:
        return app.exec()
    finally:
        database.close()


if __name__ == "__main__":
    sys.exit(main())
