"""Точка входа: python main.py"""
import sys
from pathlib import Path

# Пакет лежит в src/ — добавляем каталог в sys.path, чтобы запуск работал без установки.
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from musicbox.app import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
