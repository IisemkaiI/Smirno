import re
from datetime import date

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction

from .models import Bank, Profile

User = get_user_model()


class RegistrationForm(UserCreationForm):
    first_name = forms.CharField(label="Имя", max_length=50)
    last_name = forms.CharField(label="Фамилия", max_length=50)
    email = forms.EmailField(label="Электронная почта")
    phone = forms.CharField(label="Телефон", max_length=20,
                            widget=forms.TextInput(attrs={"placeholder": "+7 900 123-45-67"}))
    birth_date = forms.DateField(label="Дата рождения",
                                 widget=forms.DateInput(attrs={"type": "date"}))
    bank = forms.ModelChoiceField(label="Банк", queryset=Bank.objects.all(),
                                  widget=forms.RadioSelect, empty_label=None)
    agree = forms.BooleanField(
        label="Я согласен(на) на обработку персональных данных",
        error_messages={"required": "Нужно принять условия, чтобы продолжить."},
    )

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email")
        labels = {"username": "Логин"}

    def clean_email(self):
        email = self.cleaned_data["email"].lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Эта почта уже используется. Войдите или укажите другую.")
        return email

    def clean_phone(self):
        raw = self.cleaned_data["phone"]
        digits = re.sub(r"\D", "", raw)
        if len(digits) == 11 and digits[0] in "78":
            digits = "7" + digits[1:]
        elif len(digits) == 10:
            digits = "7" + digits
        else:
            raise forms.ValidationError("Введите российский номер, например +7 900 123-45-67.")
        if Profile.objects.filter(phone=f"+{digits}").exists():
            raise forms.ValidationError("Этот номер уже зарегистрирован.")
        return f"+{digits}"

    def clean_birth_date(self):
        born = self.cleaned_data["birth_date"]
        today = date.today()
        age = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
        if born > today:
            raise forms.ValidationError("Дата рождения не может быть в будущем.")
        if age < 18:
            raise forms.ValidationError("Открыть счёт можно с 18 лет.")
        if age > 120:
            raise forms.ValidationError("Проверьте год рождения.")
        return born

    @transaction.atomic
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        user.save()
        Profile.objects.create(
            user=user,
            bank=self.cleaned_data["bank"],
            phone=self.cleaned_data["phone"],
            birth_date=self.cleaned_data["birth_date"],
        )
        return user
