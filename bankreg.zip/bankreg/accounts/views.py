from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from .forms import RegistrationForm
from .models import Bank


def home(request):
    return render(request, "accounts/home.html", {"banks": Bank.objects.all()})


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Готово! Счёт открыт, добро пожаловать.")
        return redirect("dashboard")

    selected = request.POST.get("bank") or request.GET.get("bank")
    return render(request, "accounts/register.html", {
        "form": form,
        "banks": Bank.objects.all(),
        "selected_bank": str(selected) if selected else "",
    })


@login_required
def dashboard(request):
    profile = getattr(request.user, "profile", None)
    if profile is None:  # например, суперпользователь, созданный через createsuperuser
        messages.info(request, "У этой учётной записи нет банковского профиля.")
        return redirect("home")
    return render(request, "accounts/dashboard.html", {"profile": profile})
