import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Bank",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=50, unique=True, verbose_name="Название")),
                ("slug", models.SlugField(unique=True)),
                ("color", models.CharField(max_length=7, verbose_name="Цвет")),
                ("text_color", models.CharField(default="#ffffff", max_length=7, verbose_name="Цвет текста")),
                ("tagline", models.CharField(max_length=120, verbose_name="Описание")),
            ],
            options={
                "verbose_name": "банк",
                "verbose_name_plural": "банки",
                "ordering": ["id"],
            },
        ),
        migrations.CreateModel(
            name="Profile",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("phone", models.CharField(max_length=20, verbose_name="Телефон")),
                ("birth_date", models.DateField(verbose_name="Дата рождения")),
                ("account_number", models.CharField(blank=True, editable=False, max_length=20, unique=True, verbose_name="Номер счёта")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("bank", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="profiles", to="accounts.bank")),
                ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="profile", to=settings.AUTH_USER_MODEL)),
            ],
            options={
                "verbose_name": "профиль клиента",
                "verbose_name_plural": "профили клиентов",
            },
        ),
    ]
