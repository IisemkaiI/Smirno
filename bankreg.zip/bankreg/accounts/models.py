import random

from django.conf import settings
from django.db import models


class Bank(models.Model):
    name = models.CharField("Название", max_length=50, unique=True)
    slug = models.SlugField(unique=True)
    color = models.CharField("Цвет", max_length=7)
    text_color = models.CharField("Цвет текста", max_length=7, default="#ffffff")
    tagline = models.CharField("Описание", max_length=120)

    class Meta:
        verbose_name = "банк"
        verbose_name_plural = "банки"
        ordering = ["id"]

    def __str__(self):
        return self.name


def generate_account_number():
    """Учебный 20-значный номер счёта (по формату похож на реальный)."""
    return "40817810" + "".join(random.choices("0123456789", k=12))


class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile"
    )
    bank = models.ForeignKey(Bank, on_delete=models.PROTECT, related_name="profiles")
    phone = models.CharField("Телефон", max_length=20)
    birth_date = models.DateField("Дата рождения")
    account_number = models.CharField(
        "Номер счёта", max_length=20, unique=True, editable=False, blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "профиль клиента"
        verbose_name_plural = "профили клиентов"

    def save(self, *args, **kwargs):
        if not self.account_number:
            number = generate_account_number()
            while Profile.objects.filter(account_number=number).exists():
                number = generate_account_number()
            self.account_number = number
        super().save(*args, **kwargs)

    @property
    def masked_account(self):
        return f"{self.account_number[:4]} •••• •••• {self.account_number[-4:]}"

    def __str__(self):
        return f"{self.user} — {self.bank}"
