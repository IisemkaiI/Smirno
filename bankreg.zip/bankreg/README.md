# Мой банк — учебный проект на Django

Регистрация клиента в «банковской системе» с выбором банка: Т-Банк (Тинькофф), Сбербанк, Альфа-Банк.

## Запуск

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate        # создаст БД и добавит три банка
python manage.py createsuperuser  # по желанию, для /admin/
python manage.py runserver
```

Открыть: http://127.0.0.1:8000/

## Что внутри

- `accounts/models.py` — `Bank` и `Profile` (телефон, дата рождения, автогенерируемый 20-значный номер счёта)
- `accounts/forms.py` — форма регистрации: проверка возраста (18+), телефона, уникальности почты, пароля
- `accounts/views.py` — главная, регистрация, личный кабинет
- `accounts/migrations/0002_seed_banks.py` — начальные данные (банки)
- `templates/`, `static/css/style.css` — интерфейс

Названия банков используются только как пример. Проект не связан с реальными банками, не вводите настоящие данные.
